#!/bin/bash

if [ "$1" = "-help" ]; then
	echo "Uso: $0 ORIGEN DESTINO"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

if [ $# -ne 2 ]; then
	echo "Error: debe indicar ORIGEN y DESTINO"
	echo "Use: $0 -help"
	exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

if [ ! -d "$ORIGEN" ]; then
	echo "Error: el origen no existe o no esta disponible"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el destino no exite o no esta disponible" 
	exit 1
fi

if ! mountpoint -q "$DESTINO"; then
	echo "Error: el destino no esta montado"
	exit 1
fi

NOMBRE=$(basename "$ORIGEN")


ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

echo "Backup creado: $DESTINO/$ARCHIVO"
