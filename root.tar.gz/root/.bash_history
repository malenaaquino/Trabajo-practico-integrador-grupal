history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
poweroff
cat /etc/debian_version
apt update
apt upgrade
apt autoremove
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
apt full-upgrade
reboot
cat /etc/debian_version
poweroff
ssh-keygen
exit
exit
exit
exit
apt install openssh-server
nano /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
systemctl restart ssh
su
ssh-keygen
ls /root/.ssh
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.shh
pwd
ls -la /root
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ip a
hostname -i
hostname -I
poweroff
cd "$env:USERPROFILE\Downloads"
exit
php -v
apache2 -v
systemctl start apache2
systemctl enable apache2
systemctl status apache2
ls -la /root
ls -la /root/index.php
ls -la /root
cd /root
cd Material_Adicional_TPVNCA.tar.gz
cd Material_Adicional_TPVmCA.tar.gz
cd Material_Adicional_TPVMCA.tar.gz
cd /Material_Adicional_TPVMCA.tar.gz
ls -la /Material_Adicional_TPVMCA.tar.gz
ls -la Material_Adicional_TPVMCA.tar.gz
tar -tzf Material_Adicional_TPVMCA.tar.gz
tar -xzf Material_Adicional_TPVMCA.tar.gz
ls -la /root
mv "/root/logo (1).png" /root/logo.png
ls -la /root
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
ls /var/www/html
apt install php-mysql
systemctl restart apache2
echo "<?php phpinfo(); ?>" > /var/www/html/test.php
vi /var/www/html/index.php
systemctl restart apache2
apt install mariadb-server php-mysql
systemctl restart apache2
systemctl start mariadb
systemctl enable mariadb
tail -n 30 /var/log/apache2/error.log
vi /var/www/html/index.php
vi /var/www/html/index.php
apt install mariadb-server
mariadb
mariadb < /root/db.sql
ls -la /root
mariadb < /root/Material_Adicional_TPVMCA/db.sql
systemctl restart apache2
mariadb -e "SHOW DATABASES;"
poweriff
poweroff
vim /etc/network/interfaces
/etc/init.d/networking restart
cat /etc/network/interfaces
vim /etc/network/interfaces
/etc/init.d/networking restart
ping 8.8.8.8
poweroff
lsblk
fdisk /dev/sdc
lsblk
poweroff
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir 
ip a
ip link set enp0s up
ip link set enp0s3 up
ifup enp0s3
vi /etc/network/interfaces
ip a
ifup enp0s3
ip a
reboot
ip a
mkfs.ext4 /dev/sdc1
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
lsblk
power off
poweroff
lsblk
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
lsblk
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
ls -la /www_dir
vi /etc/apache2/sites.available/000-default.conf
vi /etc/apache2/sites-available/000-default.conf
vi /etc/apache2/apache2.conf
vi /etc/apache2/apache2.conf
systemctl restart apache2
blkid
vi /etc/fstab
mount -a
lsblk
reboot
ls -l
ls -l /opt/scripts
mkdir -p /opt/scripts
touch /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
ls -l /opt/scripts
vim /opt/scripts/backup_full.sh
poweroff
vim /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
ls -la /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
vim /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /deer
crontab -e
crontab -1
crontab -l
crontab -e
crontab -l
systemcrl status cron
systemctrl status cron
systemctl status cron
tar -tzf /backup_dir/log_bkp_20260604.tar.gz
poweroff
